package com.example.myapplication7;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity7 extends AppCompatActivity {
    String text;
    int p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);



        TextView textView = findViewById(R.id.textView10);
        Button button = findViewById(R.id.filebutton);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = "";
                try {
                    InputStream inputStream = getAssets().open("mytext.txt");
                    int size = inputStream.available();
                    byte[] buffer = new byte[size];
                    inputStream.read(buffer);

                    str = new String(buffer);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                textView.setText(str);

            }
        });







    }
}












